/*
 Inspired by news feed on NBA.com
 Pulls News feed data from dunktest RSS feed including image, link title and description in XML format
 puts feed data into a list and using CSS makes the new feeds items
 RSS feed uses enclosure tag wit

ref 
dealing with cors and pulling in RSS feed data https://www.geeksforgeeks.org/how-to-fetch-and-parse-rss-feeds-in-javascript/ 
working with XML - https://www.w3schools.com/xml/xml_parser.asp
 RSS Feed source UTR https://www.dunkest.com/en/rss/news/nba/latest
 
 adding hover text to header to change font colour


*/


  async function getData() {
    const proxyUrl = 'https://api.allorigins.win/get?url=';
    const url = "https://www.dunkest.com/en/rss/news/nba/latest";
    try {
      const response = await fetch(`${proxyUrl}${encodeURIComponent(url)}`);
      if (!response.ok) {
        throw new Error(`Response status: ${response.status}`);
      }
  
      const res = await response.json();
     // console.log(res.contents);
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(res.contents, 'text/xml');
     /* console.log(xmlDoc);*/

      const items = xmlDoc.querySelectorAll("item");


      let tabledata=""; 
      let listdata="";

      items.forEach(item =>{
          
          /*put xml values into variables*/
          title = item.querySelector("title").textContent;
          description = item.querySelector("description").textContent;
          link = item.querySelector("link").textContent;
          pubDate = item.querySelector("pubDate").textContent;
          enclosure = item.querySelector("enclosure").getAttribute("url");
          /*console.log(enclosure);*/
          
          /*originally I put this into a table*/
          tabledata+= `<tr>
             <td><img src="${enclosure}" width="350" height="200"> </td>
              <td><a href=${link} target="_blank">${title}<a></td>
              <td>${description}</td>
              <td>${pubDate}</td>
          </tr>`;
      
        /*exclude any where the title starts with NBA odds*/
        if (title.substring(0,8)=="NBA Odds"){
          console.log(title);
        }  
        else{
          listdata+= 
            `<li>
              <div class="flex-container container">
                  <div class="flex-child image">
                    <img src="${enclosure}" width="350" height="250"/>
                  </div>
                  <div class="flex-child newstext">
                      <p><h3><a href=${link} target="_blank">${title}</a></h3></p>
                      <p><h6>${description}</h6></p>
                      <p><h8><i>${pubDate}</i></h8></p> 

                  </div>
                </div>  
            </li>`;
          }
        })
    /*  document.getElementById("tablebody").innerHTML=tabledata; */
      document.getElementById("newslist").innerHTML=listdata;


    } catch (error) {
      console.error(error.message);
    }
  }

  getData();